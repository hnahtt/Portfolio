## Package is abandoned in favor of http://github.com/creativebulma/bulma-divider

# bulma-divider
Bulma's extension to easily display an horizontal or vertical divider
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-divider.svg)](https://www.npmjs.com/package/bulma-divider)
[![npm](https://img.shields.io/npm/dm/bulma-divider.svg)](https://www.npmjs.com/package/bulma-divider)
[![Build Status](https://travis-ci.org/Wikiki/bulma-divider.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-divider)

<img src="https://img4.hostingpics.net/pics/552370ScreenShot20170809at203028.png">

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/layout/divider/)
